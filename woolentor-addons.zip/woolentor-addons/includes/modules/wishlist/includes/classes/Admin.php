<?php
namespace WishSuite;

/**
 * Admin handlers class
 */
class Admin {

    /**
     * [$_instance]
     * @var null
     */
    private static $_instance = null;

    /**
     * [instance] Initializes a singleton instance
     * @return [Admin]
     */
    public static function instance() {
        if ( is_null( self::$_instance ) ) {
            self::$_instance = new self();
        }
        return self::$_instance;
    }
    
    /**
     * Initialize the class
     */
    private function __construct() {
        require_once( __DIR__. '/Admin/Dashboard.php' );
        Admin\Dashboard::instance();
    }

}